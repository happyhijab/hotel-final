package com.example.coba

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
